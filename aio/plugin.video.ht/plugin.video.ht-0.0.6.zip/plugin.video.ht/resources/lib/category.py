import requests
import xbmcgui
from bs4 import BeautifulSoup
from xbmcaddon import Addon


ADDON = Addon(id='plugin.video.ht')
main_url = ADDON.getSetting("main_url")


def parse(url):
	try:
		r = requests.get(url)
	except requests.exceptions.ConnectionError as e:
		dialog = xbmcgui.Dialog()
		dialog.ok("[COLOR red][U]Network Issue[/U][/COLOR]","[COLOR yellow]Temporary Not Availabe[/COLOR]")
		raise SystemExit(e)	
	soup = BeautifulSoup(r.content, 'html.parser')
	return(soup)


def get_links(soup):
	# For links
	for l in soup.select(".items li a"):
		yield (l["href"])

		
def get_images(soup):
	# for images
	for i in soup.select("img.movie"):
		yield (i["src"])


def get_links_2(soup):
	# For links
	for l in soup.select(".link-item a"):
		yield (l["href"])


def get_links_3(soup):
	# For links
	for l in soup.select(".link-item a"):
		yield (l["href"])
