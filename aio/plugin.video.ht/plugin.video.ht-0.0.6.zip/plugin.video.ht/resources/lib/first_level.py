import sys
import xbmc
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from urlparse import parse_qsl
from resources.lib import get_url, category, extractMY

addon_handle = int(sys.argv[1])
ADDON = Addon(id='plugin.video.ht')
main_url = ADDON.getSetting("main_url")

	
def addDir():
	#xbmc.log('total number of pages %s'%(str(len(movies))),xbmc.LOGNOTICE)
	params = dict(parse_qsl(sys.argv[2][1:]))
	link = params['action']
	if params.has_key('page'):
		page = int(params['page'])
		soup = category.parse('{}&p={}'.format(link,page))
	else:
		soup = category.parse(link)
		page = 1
	movies = category.get_links(soup)
	listing = []
	
	nextPage = xbmcgui.ListItem('[COLOR blue]Next Page[/COLOR]', iconImage='DefaultFolder.png')
	url = get_url.fetch(mode='page', action=link, page=page+1)
	xbmcplugin.addDirectoryItem(addon_handle, url, nextPage,True)
	for movie in movies:
			info = extractMY.extract(movie)
			url = get_url.fetch(mode = 'second_level', action='{}/movie/{}/{}'.format(main_url, info['code'], info['raw']))
			li = xbmcgui.ListItem(label='[COLOR golden]%s[/COLOR]'%info['title'])
			poster = "{}{}".format(main_url, info['image'])
			li.setArt({'poster': poster})
			#li.setIsFolder(True)
			isFolder = True
			listing.append((url, li, isFolder))
			#xbmc.log('Data accessed through first_level - %s'%info['title'],xbmc.LOGNOTICE)
	xbmcplugin.addDirectoryItems(addon_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(addon_handle)
