import sys
import xbmcgui
from xbmcaddon import Addon
from urlparse import parse_qsl
from resources.lib import navigator, category, play_video, first_level, second_level

ADDON = Addon(id='plugin.video.ht')
main_url = ADDON.getSetting("main_url")


def router(paramstring):
	params = dict(parse_qsl(paramstring))
	
	if params:
		if params['mode'] == 'main':
			navigator.getSubMenu(params['category'])
		elif params['mode'] == 'first_level':
			first_level.addDir()
		elif params['mode'] == 'second_level':
			second_level.addDir()
		elif params['mode'] == 'third_level':
			third_level.addDir()
		elif params['mode'] == 'page':
			first_level.addDir()
		elif params['mode'] == 'video':
			play_video.play()
		else:
			raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
	else:
		navigator.getMainMenu()

if __name__ == '__main__':
	router(sys.argv[2][1:])
