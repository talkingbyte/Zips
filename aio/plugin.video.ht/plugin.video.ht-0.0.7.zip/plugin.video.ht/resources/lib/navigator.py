import os
import sys
import xbmc
import xbmcgui
from xbmcaddon import Addon
import xbmcplugin
from urlparse import parse_qsl
from resources.lib import get_url


ADDON = Addon(id='plugin.video.ht')
main_url = ADDON.getSetting("main_url")
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]
imgPath = xbmc.translatePath('special://home/addons/plugin.video.ht/resources/media')

listing = [{'name': 'Bollywood', 'link': '{}/1/bollywood-movies.html'.format(main_url), 'poster': 'Bollywood.png'},
			{'name': 'Hollywood', 'link': '{}/5/hollywood-movies.html'.format(main_url), 'poster': 'Hollywood.png'},
			{'name': 'Hollywood Dubbed', 'link': '{}/2/hollywood-dual-audio-hindi-movies.html'.format(main_url), 'poster': 'Dual Audio.png'},
			{'name': 'South Dubbed', 'link': '{}/45/south-indian-hindi-dubbed-movies.html'.format(main_url), 'poster': 'South Dubbed.png'}]


def getMainMenu():
	# li_download = xbmcgui.ListItem('[COLOR green]DOWNLOADS[/COLOR]')
	# url = get_url.fetch(mode = 'check download')
	# li_download.setArt({'poster': '{}/Download.png'.format(imgPath)})
	# li_download.setIsFolder(True)
	# xbmcplugin.addDirectoryItem(addon_handle,url,li_download,True)
	
	for cat in listing:
		li = xbmcgui.ListItem(label="[COLOR yellow]%s[/COLOR]"%cat['name'])
		url = get_url.fetch(mode='first_level', action=cat['link'])
		li.setArt({'poster': '{}/{}'.format(imgPath, cat['poster'])})
		li.setIsFolder(False)
		xbmcplugin.addDirectoryItem(addon_handle, url, li, True)
		#xbmc.log('Data accessed through navigator - %s'%cat['name'],xbmc.LOGNOTICE)
	xbmcplugin.endOfDirectory(addon_handle)	
	
