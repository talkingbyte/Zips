import sys
import xbmc
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from urlparse import parse_qsl
from resources.lib import category, extractMY, get_url



addon_handle = int(sys.argv[1])
ADDON = Addon(id='plugin.video.ht')
main_url = ADDON.getSetting("main_url")
#bgFile = xbmc.translatePath('special://home/addons/plugin.video.ht/resources/fanart.jpg')

	
def addDir():
	params = dict(parse_qsl(sys.argv[2][1:]))
	link = params['action']
	soup = category.parse(link)
	movies = category.get_links_2(soup)
	listing = []
	
	#xbmc.log('total number of pages %s'%(str(len(movies))),xbmc.LOGNOTICE)
	for movie in movies:
		soup_final = category.parse('{}{}'.format(main_url,movie))
		video_host_path = category.get_links_3(soup_final)		
		info = extractMY.extract(movie)
		url = get_url.fetch(mode = 'video' , video_path = video_host_path)
		li = xbmcgui.ListItem(label='[COLOR golden]%s[/COLOR]'%info['title'])
		li.setInfo('video', {'title': info['title'], 'mediatype': 'movies'})
		li.setArt({'icon': 'DefaultVideo.png',
					   'poster': 'DefaultVideo.png'})
		#li.setIsFolder(True)
		li.setProperty('IsPlayable', 'true')
		isFolder = False
		listing.append((url, li, isFolder))
		# dialog = xbmcgui.Dialog()
		# dialog.ok("[COLOR red][U]Important[/U][/COLOR]","[COLOR yellow]%s[/COLOR]"%info['raw'])
		#xbmc.log('Data accessed through second_level - %s'%info['raw'],xbmc.LOGNOTICE)
	xbmcplugin.addDirectoryItems(addon_handle, listing, len(listing))
	xbmcplugin.endOfDirectory(addon_handle)
	
