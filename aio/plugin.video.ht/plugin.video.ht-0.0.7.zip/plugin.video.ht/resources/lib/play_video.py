import sys
import xbmcgui
import xbmcplugin
from xbmcaddon import Addon
from urlparse import parse_qsl

ADDON = Addon(id='plugin.video.ht')
addon_handle = int(sys.argv[1])

def play():
	params = dict(parse_qsl(sys.argv[2][1:]))
	path = params['video_path']
	play_item = xbmcgui.ListItem(path=path)
	xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
